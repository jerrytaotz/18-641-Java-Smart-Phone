package adapter;
public interface FixAuto {
	public void fix(int errno);
}