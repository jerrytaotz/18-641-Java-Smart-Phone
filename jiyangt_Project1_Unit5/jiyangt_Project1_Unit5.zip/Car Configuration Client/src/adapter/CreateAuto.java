package adapter;
public interface CreateAuto {
	public void BuildAuto(String filename, String fileType);
	
	public void printAuto(String Modelname);
}