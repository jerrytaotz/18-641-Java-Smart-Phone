package adapter;

import java.util.Properties;

import server.AutoServer;

public class BuildAuto extends ProxyAutomobile 
implements CreateAuto, UpdateAuto, FixAuto, EditAuto, AutoServer {
	
}