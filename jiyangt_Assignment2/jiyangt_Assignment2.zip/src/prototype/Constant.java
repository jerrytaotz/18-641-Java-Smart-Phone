package prototype;
/**
 * 
 * @author Jiyang Tao
 * @andrewID jiangt
 * @date Jan 20, 2016
 * 
 * This interface define two constants.
 */
public interface Constant {
	static final int MAX_STUDENT = 40;
	static final int QUIZ_NUM = 5;
}