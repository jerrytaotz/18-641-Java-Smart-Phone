package adapter;
public interface CreateAuto {
	public void BuildAuto(String filename);
	
	public void printAuto(String Modelname);
}